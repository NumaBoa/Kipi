import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Estrutura } from "@/components/app/estrutura";
import { Etiqueta, Painel, TituloSecao, Vazio } from "@/components/app/painel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { brl, num } from "@/lib/format";
import {
  custoProduto,
  useApagarReceitaItem,
  useInsumos,
  useProdutos,
  useReceitas,
  useSalvarReceitaItem,
} from "@/lib/dados";

export const Route = createFileRoute("/_authenticated/receitas")({
  head: () => ({
    meta: [
      { title: "Receitas — Meu Ateliê" },
      {
        name: "description",
        content:
          "Fichas técnicas: quais ingredientes e materiais cada bolo ou cookie consome e quanto custa.",
      },
      { property: "og:title", content: "Receitas — Meu Ateliê" },
      {
        property: "og:description",
        content:
          "Fichas técnicas: quais ingredientes e materiais cada bolo ou cookie consome e quanto custa.",
      },
    ],
  }),
  component: PaginaReceitas,
});

function PaginaReceitas() {
  const { data: produtos = [] } = useProdutos();
  const { data: insumos = [] } = useInsumos();
  const { data: receitas = [] } = useReceitas();
  const adicionar = useSalvarReceitaItem();
  const apagar = useApagarReceitaItem();

  const [produtoId, setProdutoId] = useState<string>("");
  const [insumoId, setInsumoId] = useState<string>("");
  const [quantidade, setQuantidade] = useState("");

  useEffect(() => {
    const primeiro = produtos[0];
    if (!produtoId && primeiro) setProdutoId(primeiro.id);
  }, [produtos, produtoId]);

  const produto = produtos.find((p) => p.id === produtoId);
  const itens = receitas.filter((r) => r.produto_id === produtoId);
  const custo = produtoId ? custoProduto(produtoId, receitas, insumos) : 0;
  const preco = Number(produto?.preco ?? 0);
  const margem = preco > 0 ? ((preco - custo) / preco) * 100 : 0;

  const incluir = async () => {
    const qtd = Number(quantidade.replace(",", "."));
    if (!produtoId || !insumoId || !qtd) {
      toast.error("Escolha o item e a quantidade usada.");
      return;
    }
    await adicionar.mutateAsync({ produto_id: produtoId, insumo_id: insumoId, quantidade: qtd });
    setQuantidade("");
    toast.success("Item adicionado à receita.");
  };

  return (
    <Estrutura titulo="Receitas" subtitulo="Fichas técnicas e custo">
      <div className="grid gap-4 lg:grid-cols-3">
        <Painel className="p-6 lg:col-span-2">
          <TituloSecao
            titulo="Ficha técnica"
            descricao="O que cada unidade do produto consome"
            acao={
              <Select value={produtoId} onValueChange={setProdutoId}>
                <SelectTrigger className="w-[210px] rounded-full text-xs">
                  <SelectValue placeholder="Escolha o produto" />
                </SelectTrigger>
                <SelectContent>
                  {produtos.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            }
          />

          <div className="mt-4 space-y-2">
            {itens.length === 0 ? (
              <Vazio texto="Essa receita ainda não tem ingredientes." />
            ) : (
              itens.map((item) => {
                const insumo = insumos.find((i) => i.id === item.insumo_id);
                const subtotal = insumo
                  ? Number(insumo.custo_unitario) * Number(item.quantidade)
                  : 0;
                return (
                  <div
                    key={item.id}
                    className="glass-inset grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-2xl px-4 py-2.5"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{insumo?.nome ?? "Item"}</p>
                      <p className="text-xs text-muted-foreground">
                        {num(Number(item.quantidade))} {insumo?.unidade} · {insumo?.tipo}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <span className="text-sm tabular-nums">{brl(subtotal)}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 rounded-full text-muted-foreground"
                        aria-label="Remover"
                        onClick={() => apagar.mutate(item.id)}
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-[minmax(0,1fr)_120px_auto] sm:items-end">
            <div className="space-y-1.5">
              <Label>Ingrediente ou material</Label>
              <Select value={insumoId} onValueChange={setInsumoId}>
                <SelectTrigger>
                  <SelectValue placeholder="Escolha um item" />
                </SelectTrigger>
                <SelectContent>
                  {insumos.map((i) => (
                    <SelectItem key={i.id} value={i.id}>
                      {i.nome} ({i.unidade})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="qtd-receita">Quantidade</Label>
              <Input
                id="qtd-receita"
                inputMode="decimal"
                value={quantidade}
                onChange={(e) => setQuantidade(e.target.value)}
                placeholder="0,5"
              />
            </div>
            <Button className="rounded-2xl" onClick={incluir} disabled={adicionar.isPending}>
              <Plus className="size-4" /> Adicionar
            </Button>
          </div>
        </Painel>

        <Painel className="p-6">
          <TituloSecao titulo="Preço e lucro" descricao={produto?.nome ?? "Escolha um produto"} />
          <div className="mt-4 space-y-3 text-sm">
            <div className="glass-inset flex items-center justify-between rounded-2xl px-4 py-3">
              <span className="text-muted-foreground">Custo por unidade</span>
              <span className="tabular-nums">{brl(custo)}</span>
            </div>
            <div className="glass-inset flex items-center justify-between rounded-2xl px-4 py-3">
              <span className="text-muted-foreground">Preço de venda</span>
              <span className="tabular-nums">{brl(preco)}</span>
            </div>
            <div className="glass-inset flex items-center justify-between rounded-2xl px-4 py-3">
              <span className="text-muted-foreground">Lucro por unidade</span>
              <span className="font-medium text-success tabular-nums">{brl(preco - custo)}</span>
            </div>
            <div className="flex items-center justify-between px-1">
              <span className="text-muted-foreground">Margem</span>
              <Etiqueta tom={margem >= 40 ? "success" : margem > 0 ? "warning" : "danger"}>
                {num(margem, 0)}%
              </Etiqueta>
            </div>
            <p className="px-1 text-xs text-muted-foreground">
              Sugestão de preço com margem de 50%: <strong>{brl(custo * 2)}</strong>.
            </p>
          </div>
        </Painel>
      </div>
    </Estrutura>
  );
}
