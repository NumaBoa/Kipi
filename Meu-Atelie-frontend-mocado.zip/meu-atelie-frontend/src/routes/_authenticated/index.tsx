import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { Estrutura } from "@/components/app/estrutura";
import { CartaoIndicador, Etiqueta, Painel, TituloSecao, Vazio } from "@/components/app/painel";
import { Button } from "@/components/ui/button";
import { brl, dataHora, num } from "@/lib/format";
import { statusInsumo, useInsumos, useProdutos, useClientes, useVendas } from "@/lib/dados";

export const Route = createFileRoute("/_authenticated/")({
  head: () => ({
    meta: [
      { title: "Painel — Meu Ateliê" },
      {
        name: "description",
        content: "Faturamento, pedidos do dia e alertas de estoque da confeitaria num só painel.",
      },
      { property: "og:title", content: "Painel — Meu Ateliê" },
      {
        property: "og:description",
        content: "Faturamento, pedidos do dia e alertas de estoque da confeitaria num só painel.",
      },
    ],
  }),
  component: PainelInicial,
});

const DIAS = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];

function PainelInicial() {
  const { data: vendas = [] } = useVendas();
  const { data: insumos = [] } = useInsumos();
  const { data: produtos = [] } = useProdutos();
  const { data: clientes = [] } = useClientes();

  const validas = vendas.filter((v) => v.status !== "cancelado");
  const inicioHoje = new Date();
  inicioHoje.setHours(0, 0, 0, 0);

  const doDia = validas.filter((v) => new Date(v.data) >= inicioHoje);
  const faturamentoDia = doDia.reduce((s, v) => s + Number(v.total), 0);

  const seteDias = new Date(Date.now() - 6 * 86400000);
  seteDias.setHours(0, 0, 0, 0);
  const daSemana = validas.filter((v) => new Date(v.data) >= seteDias);
  const faturamentoSemana = daSemana.reduce((s, v) => s + Number(v.total), 0);
  const lucroSemana = daSemana.reduce((s, v) => s + Number(v.total) - Number(v.custo_total), 0);
  const margem = faturamentoSemana > 0 ? (lucroSemana / faturamentoSemana) * 100 : 0;

  const pendentes = validas.filter((v) => v.status === "pendente");
  const aReceber = pendentes.reduce((s, v) => s + Number(v.total), 0);

  const baixos = insumos.filter((i) => statusInsumo(i) !== "ok");
  const estoquePronto = produtos.reduce((s, p) => s + Number(p.estoque), 0);

  const barras = Array.from({ length: 7 }, (_, indice) => {
    const dia = new Date(Date.now() - (6 - indice) * 86400000);
    dia.setHours(0, 0, 0, 0);
    const fim = new Date(dia.getTime() + 86400000);
    const valor = validas
      .filter((v) => new Date(v.data) >= dia && new Date(v.data) < fim)
      .reduce((s, v) => s + Number(v.total), 0);
    return { rotulo: DIAS[dia.getDay()], valor, hoje: indice === 6 };
  });
  const maior = Math.max(...barras.map((b) => b.valor), 1);

  return (
    <Estrutura
      titulo="Painel"
      acao={
        <Button asChild className="rounded-2xl">
          <Link to="/vendas">
            <Plus className="size-4" /> Nova venda
          </Link>
        </Button>
      }
    >
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <CartaoIndicador
          rotulo="Faturamento hoje"
          valor={brl(faturamentoDia)}
          detalhe={`${doDia.length} ${doDia.length === 1 ? "venda registrada" : "vendas registradas"}`}
          etiqueta="hoje"
          tom="brand"
        />
        <CartaoIndicador
          rotulo="Faturamento 7 dias"
          valor={brl(faturamentoSemana)}
          detalhe={`Lucro de ${brl(lucroSemana)} · margem ${num(margem, 0)}%`}
          etiqueta="semana"
          tom="blossom"
        />
        <CartaoIndicador
          rotulo="A receber"
          valor={brl(aReceber)}
          detalhe={`${pendentes.length} ${pendentes.length === 1 ? "pedido pendente" : "pedidos pendentes"}`}
          etiqueta={pendentes.length ? "atenção" : "em dia"}
          tom={pendentes.length ? "warning" : "success"}
        />
        <CartaoIndicador
          rotulo="Estoque de produtos"
          valor={`${num(estoquePronto, 0)} un`}
          detalhe={`${produtos.length} produtos · ${clientes.length} clientes`}
          etiqueta={baixos.length ? `${baixos.length} repor` : "ok"}
          tom={baixos.length ? "danger" : "success"}
        />
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <Painel className="p-6 lg:col-span-2">
          <TituloSecao
            titulo="Vendas da semana"
            descricao="Bolos, cookies e encomendas"
            acao={<Etiqueta tom="neutro">Últimos 7 dias</Etiqueta>}
          />
          <div className="mt-6 flex h-40 items-end gap-2 sm:gap-3">
            {barras.map((barra, i) => (
              <div key={i} className="flex min-w-0 flex-1 flex-col items-center gap-2">
                <span className="text-[10px] text-muted-foreground tabular-nums">
                  {barra.valor > 0 ? num(barra.valor, 0) : ""}
                </span>
                <div
                  className={
                    barra.hoje
                      ? "gradient-brand w-full rounded-t-xl"
                      : "w-full rounded-t-xl bg-brand/35"
                  }
                  style={{ height: `${Math.max((barra.valor / maior) * 100, 4)}%` }}
                />
                <span
                  className={
                    barra.hoje
                      ? "text-[11px] font-semibold text-brand"
                      : "text-[11px] text-muted-foreground"
                  }
                >
                  {barra.rotulo}
                </span>
              </div>
            ))}
          </div>
        </Painel>

        <Painel className="p-6">
          <TituloSecao titulo="Precisa repor" descricao="Ingredientes e materiais no limite" />
          <div className="mt-4 space-y-3">
            {baixos.length === 0 ? (
              <Vazio texto="Tudo abastecido por aqui." />
            ) : (
              baixos.slice(0, 5).map((insumo) => {
                const alvo = Math.max(Number(insumo.minimo), 1);
                const proporcao = Math.min((Number(insumo.quantidade) / alvo) * 100, 100);
                return (
                  <div key={insumo.id} className="glass-inset rounded-2xl p-3">
                    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 text-sm">
                      <span className="truncate font-medium">{insumo.nome}</span>
                      <span className="text-xs text-muted-foreground tabular-nums">
                        {num(Number(insumo.quantidade))} / {num(alvo)} {insumo.unidade}
                      </span>
                    </div>
                    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-foreground/10">
                      <div
                        className="h-full rounded-full bg-danger"
                        style={{ width: `${Math.max(proporcao, 4)}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
          <Button asChild variant="outline" className="mt-4 w-full rounded-2xl">
            <Link to="/estoque">Abrir estoque</Link>
          </Button>
        </Painel>
      </section>

      <Painel className="p-6">
        <TituloSecao
          titulo="Pedidos recentes"
          descricao="As últimas vendas registradas"
          acao={
            <Button asChild variant="ghost" size="sm" className="rounded-full">
              <Link to="/vendas">Ver todos</Link>
            </Button>
          }
        />
        <div className="mt-4 space-y-2 text-sm">
          {vendas.length === 0 ? (
            <Vazio texto="Nenhuma venda registrada ainda." />
          ) : (
            vendas.slice(0, 5).map((venda, indice) => (
              <div
                key={venda.id}
                className="glass-inset grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-2xl px-3 py-3 sm:px-4"
              >
                <div className="grid size-9 shrink-0 place-items-center rounded-xl bg-brand/12 text-xs font-bold text-brand">
                  {String(vendas.length - indice).padStart(2, "0")}
                </div>
                <div className="min-w-0">
                  <p className="truncate font-medium">
                    {venda.venda_itens.map((i) => `${num(i.quantidade, 0)}× ${i.nome_produto}`).join(", ") ||
                      "Venda"}
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    {venda.clientes?.nome ?? "Sem cliente"} · {dataHora(venda.data)}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-2 sm:gap-3">
                  <span className="text-sm font-semibold tabular-nums">{brl(Number(venda.total))}</span>
                  <Etiqueta
                    tom={
                      venda.status === "pago"
                        ? "success"
                        : venda.status === "pendente"
                          ? "warning"
                          : "danger"
                    }
                  >
                    {venda.status}
                  </Etiqueta>
                </div>
              </div>
            ))
          )}
        </div>
      </Painel>
    </Estrutura>
  );
}
