import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Estrutura } from "@/components/app/estrutura";
import { Etiqueta, Painel, TituloSecao, Vazio } from "@/components/app/painel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { brl, num } from "@/lib/format";
import {
  custoProduto,
  useApagarProduto,
  useInsumos,
  useProdutos,
  useReceitas,
  useSalvarProduto,
  type Produto,
} from "@/lib/dados";

export const Route = createFileRoute("/_authenticated/produtos")({
  head: () => ({
    meta: [
      { title: "Produtos — Meu Ateliê" },
      {
        name: "description",
        content: "Cadastro de bolos, cookies e peças de artesanato com preço, custo e margem.",
      },
      { property: "og:title", content: "Produtos — Meu Ateliê" },
      {
        property: "og:description",
        content: "Cadastro de bolos, cookies e peças de artesanato com preço, custo e margem.",
      },
    ],
  }),
  component: PaginaProdutos,
});

const vazio = { nome: "", categoria: "bolo", preco: 0, estoque: 0, ativo: true } as Partial<Produto>;

function PaginaProdutos() {
  const { data: produtos = [] } = useProdutos();
  const { data: receitas = [] } = useReceitas();
  const { data: insumos = [] } = useInsumos();
  const salvar = useSalvarProduto();
  const apagar = useApagarProduto();

  const [aberto, setAberto] = useState(false);
  const [form, setForm] = useState<Partial<Produto>>(vazio);

  const abrir = (produto?: Produto) => {
    setForm(produto ? { ...produto } : vazio);
    setAberto(true);
  };

  const confirmar = async () => {
    if (!form.nome?.trim()) {
      toast.error("Dê um nome ao produto.");
      return;
    }
    try {
      await salvar.mutateAsync({
        ...form,
        preco: Number(form.preco) || 0,
        estoque: Number(form.estoque) || 0,
      });
      toast.success("Produto salvo.");
      setAberto(false);
    } catch (erro) {
      toast.error(erro instanceof Error ? erro.message : "Não foi possível salvar.");
    }
  };

  return (
    <Estrutura
      titulo="Produtos"
      subtitulo="Catálogo e preços"
      acao={
        <Button className="rounded-2xl" onClick={() => abrir()}>
          <Plus className="size-4" /> Novo produto
        </Button>
      }
    >
      <Painel className="p-6">
        <TituloSecao
          titulo="Catálogo"
          descricao="O custo vem da ficha técnica de cada receita"
        />
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="border-b border-border text-[11px] tracking-wider text-muted-foreground uppercase">
                <th className="py-2 pr-4 text-left font-medium">Produto</th>
                <th className="py-2 pr-4 text-left font-medium">Categoria</th>
                <th className="py-2 pr-4 text-right font-medium">Preço</th>
                <th className="py-2 pr-4 text-right font-medium">Custo</th>
                <th className="py-2 pr-4 text-right font-medium">Margem</th>
                <th className="py-2 pr-4 text-right font-medium">Estoque</th>
                <th className="py-2 text-right font-medium">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {produtos.map((produto) => {
                const custo = custoProduto(produto.id, receitas, insumos);
                const preco = Number(produto.preco);
                const margem = preco > 0 ? ((preco - custo) / preco) * 100 : 0;
                return (
                  <tr key={produto.id} className="transition-colors hover:bg-card/50">
                    <td className="py-2.5 pr-4 font-medium">
                      {produto.nome}
                      {!produto.ativo ? (
                        <Etiqueta tom="neutro" className="ml-2">
                          inativo
                        </Etiqueta>
                      ) : null}
                    </td>
                    <td className="py-2.5 pr-4 text-muted-foreground">{produto.categoria}</td>
                    <td className="py-2.5 pr-4 text-right tabular-nums">{brl(preco)}</td>
                    <td className="py-2.5 pr-4 text-right text-muted-foreground tabular-nums">
                      {custo > 0 ? brl(custo) : "—"}
                    </td>
                    <td className="py-2.5 pr-4 text-right">
                      <Etiqueta tom={margem >= 40 ? "success" : margem > 0 ? "warning" : "neutro"}>
                        {custo > 0 ? `${num(margem, 0)}%` : "sem receita"}
                      </Etiqueta>
                    </td>
                    <td className="py-2.5 pr-4 text-right tabular-nums">
                      {num(Number(produto.estoque), 0)}
                    </td>
                    <td className="py-2.5 text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 rounded-full"
                        aria-label="Editar"
                        onClick={() => abrir(produto)}
                      >
                        <Pencil className="size-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 rounded-full text-muted-foreground"
                        aria-label="Apagar"
                        onClick={() => apagar.mutate(produto.id)}
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {produtos.length === 0 ? <Vazio texto="Nenhum produto cadastrado ainda." /> : null}
        </div>
      </Painel>

      <Dialog open={aberto} onOpenChange={setAberto}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-display text-xl">
              {form.id ? "Editar produto" : "Novo produto"}
            </DialogTitle>
            <DialogDescription>
              Defina nome, preço de venda e quantas unidades já estão prontas.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="nome">Nome</Label>
              <Input
                id="nome"
                value={form.nome ?? ""}
                onChange={(e) => setForm({ ...form, nome: e.target.value })}
                placeholder="Bolo de cenoura com brigadeiro"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Categoria</Label>
              <Select
                value={form.categoria ?? "bolo"}
                onValueChange={(v) => setForm({ ...form, categoria: v as Produto["categoria"] })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bolo">Bolo</SelectItem>
                  <SelectItem value="cookie">Cookie</SelectItem>
                  <SelectItem value="artesanato">Artesanato</SelectItem>
                  <SelectItem value="outro">Outro</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="preco">Preço de venda (R$)</Label>
              <Input
                id="preco"
                type="number"
                step="0.01"
                value={String(form.preco ?? 0)}
                onChange={(e) => setForm({ ...form, preco: Number(e.target.value) })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="estoque">Unidades prontas</Label>
              <Input
                id="estoque"
                type="number"
                step="1"
                value={String(form.estoque ?? 0)}
                onChange={(e) => setForm({ ...form, estoque: Number(e.target.value) })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Situação</Label>
              <Select
                value={form.ativo === false ? "inativo" : "ativo"}
                onValueChange={(v) => setForm({ ...form, ativo: v === "ativo" })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativo">Ativo</SelectItem>
                  <SelectItem value="inativo">Inativo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="rounded-2xl" onClick={() => setAberto(false)}>
              Cancelar
            </Button>
            <Button className="rounded-2xl" onClick={confirmar} disabled={salvar.isPending}>
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Estrutura>
  );
}
