import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Minus, Plus, ShoppingCart, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Estrutura } from "@/components/app/estrutura";
import { Etiqueta, Painel, TituloSecao, Vazio } from "@/components/app/painel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { brl, dataHora, num } from "@/lib/format";
import {
  custoProduto,
  useAtualizarVenda,
  useApagarVenda,
  useClientes,
  useInsumos,
  useProdutos,
  useReceitas,
  useRegistrarVenda,
  useVendas,
  type ItemCarrinho,
  type Produto,
  type Venda,
} from "@/lib/dados";

export const Route = createFileRoute("/_authenticated/vendas")({
  head: () => ({
    meta: [
      { title: "Vendas — Meu Ateliê" },
      {
        name: "description",
        content: "Registre vendas de bolos, cookies e artesanato e acompanhe o histórico.",
      },
      { property: "og:title", content: "Vendas — Meu Ateliê" },
      {
        property: "og:description",
        content: "Registre vendas de bolos, cookies e artesanato e acompanhe o histórico.",
      },
    ],
  }),
  component: PaginaVendas,
});

function PaginaVendas() {
  const { data: produtos = [] } = useProdutos();
  const { data: clientes = [] } = useClientes();
  const { data: insumos = [] } = useInsumos();
  const { data: receitas = [] } = useReceitas();
  const { data: vendas = [] } = useVendas();

  const registrar = useRegistrarVenda();
  const atualizar = useAtualizarVenda();
  const apagar = useApagarVenda();

  const [aberto, setAberto] = useState(false);
  const [carrinho, setCarrinho] = useState<ItemCarrinho[]>([]);
  const [clienteId, setClienteId] = useState<string>("sem");
  const [pagamento, setPagamento] = useState<Venda["pagamento"]>("pix");
  const [status, setStatus] = useState<Venda["status"]>("pago");
  const [observacoes, setObservacoes] = useState("");
  const [busca, setBusca] = useState("");

  const total = carrinho.reduce((s, i) => s + Number(i.produto.preco) * i.quantidade, 0);
  const custo = carrinho.reduce(
    (s, i) => s + custoProduto(i.produto.id, receitas, insumos) * i.quantidade,
    0,
  );

  const filtrados = useMemo(
    () =>
      produtos
        .filter((p) => p.ativo)
        .filter((p) => p.nome.toLowerCase().includes(busca.trim().toLowerCase())),
    [produtos, busca],
  );

  const adicionar = (produto: Produto) =>
    setCarrinho((atual) => {
      const existe = atual.find((i) => i.produto.id === produto.id);
      if (existe)
        return atual.map((i) =>
          i.produto.id === produto.id ? { ...i, quantidade: i.quantidade + 1 } : i,
        );
      return [...atual, { produto, quantidade: 1 }];
    });

  const mudarQuantidade = (id: string, delta: number) =>
    setCarrinho((atual) =>
      atual
        .map((i) => (i.produto.id === id ? { ...i, quantidade: i.quantidade + delta } : i))
        .filter((i) => i.quantidade > 0),
    );

  const salvar = async () => {
    if (carrinho.length === 0) {
      toast.error("Adicione pelo menos um produto.");
      return;
    }
    try {
      await registrar.mutateAsync({
        itens: carrinho,
        clienteId: clienteId === "sem" ? null : clienteId,
        pagamento,
        status,
        observacoes,
        receitas,
        insumos,
      });
      toast.success("Venda registrada e estoque atualizado.");
      setCarrinho([]);
      setObservacoes("");
      setAberto(false);
    } catch (erro) {
      toast.error(erro instanceof Error ? erro.message : "Não foi possível salvar a venda.");
    }
  };

  return (
    <Estrutura
      titulo="Vendas"
      subtitulo="Registro e histórico"
      acao={
        <Button className="rounded-2xl" onClick={() => setAberto(true)}>
          <Plus className="size-4" /> Nova venda
        </Button>
      }
    >
      <Painel className="p-6">
        <TituloSecao
          titulo="Histórico de vendas"
          descricao={`${vendas.length} ${vendas.length === 1 ? "venda" : "vendas"} registradas`}
        />
        <div className="mt-4 space-y-2">
          {vendas.length === 0 ? (
            <Vazio texto="Nenhuma venda ainda. Clique em Nova venda para começar." />
          ) : (
            vendas.map((venda) => (
              <div
                key={venda.id}
                className="glass-inset grid gap-3 rounded-2xl px-4 py-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">
                    {venda.venda_itens
                      .map((i) => `${num(i.quantidade, 0)}× ${i.nome_produto}`)
                      .join(", ") || "Venda"}
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    {venda.clientes?.nome ?? "Sem cliente"} · {dataHora(venda.data)} ·{" "}
                    {venda.pagamento}
                    {venda.observacoes ? ` · ${venda.observacoes}` : ""}
                  </p>
                </div>
                <div className="flex shrink-0 flex-wrap items-center gap-2">
                  <span className="text-sm font-semibold tabular-nums">
                    {brl(Number(venda.total))}
                  </span>
                  <Etiqueta tom="brand">
                    lucro {brl(Number(venda.total) - Number(venda.custo_total))}
                  </Etiqueta>
                  <Select
                    value={venda.status}
                    onValueChange={(valor) =>
                      atualizar.mutate({ id: venda.id, status: valor as Venda["status"] })
                    }
                  >
                    <SelectTrigger className="h-8 w-[130px] rounded-full text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pago">Pago</SelectItem>
                      <SelectItem value="pendente">Pendente</SelectItem>
                      <SelectItem value="cancelado">Cancelado</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8 rounded-full text-muted-foreground"
                    aria-label="Apagar venda"
                    onClick={() => apagar.mutate(venda.id)}
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </Painel>

      <Sheet open={aberto} onOpenChange={setAberto}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-xl">
          <SheetHeader>
            <SheetTitle className="font-display text-2xl">Nova venda</SheetTitle>
            <SheetDescription>
              Escolha os produtos: o estoque e os ingredientes são descontados automaticamente.
            </SheetDescription>
          </SheetHeader>

          <div className="space-y-5 px-4 pb-8">
            <div className="space-y-2">
              <Label htmlFor="busca">Produto</Label>
              <Input
                id="busca"
                placeholder="Buscar bolo, cookie ou peça..."
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
              />
              <div className="max-h-52 space-y-1.5 overflow-y-auto pr-1">
                {filtrados.map((produto) => (
                  <button
                    key={produto.id}
                    type="button"
                    onClick={() => adicionar(produto)}
                    className="glass-inset grid w-full grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-2xl px-3 py-2 text-left transition-colors hover:bg-brand/10"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium">{produto.nome}</span>
                      <span className="text-xs text-muted-foreground">
                        {produto.categoria} · {num(Number(produto.estoque), 0)} em estoque
                      </span>
                    </span>
                    <span className="text-sm font-semibold tabular-nums">
                      {brl(Number(produto.preco))}
                    </span>
                  </button>
                ))}
                {filtrados.length === 0 ? <Vazio texto="Nenhum produto encontrado." /> : null}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Carrinho</Label>
              {carrinho.length === 0 ? (
                <Vazio texto="Carrinho vazio." />
              ) : (
                <div className="space-y-1.5">
                  {carrinho.map((item) => (
                    <div
                      key={item.produto.id}
                      className="glass-inset grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-2xl px-3 py-2"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{item.produto.nome}</p>
                        <p className="text-xs text-muted-foreground">
                          {brl(Number(item.produto.preco))} cada
                        </p>
                      </div>
                      <div className="flex shrink-0 items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-7 rounded-full"
                          aria-label="Diminuir"
                          onClick={() => mudarQuantidade(item.produto.id, -1)}
                        >
                          <Minus className="size-3.5" />
                        </Button>
                        <span className="w-6 text-center text-sm font-semibold tabular-nums">
                          {item.quantidade}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-7 rounded-full"
                          aria-label="Aumentar"
                          onClick={() => mudarQuantidade(item.produto.id, 1)}
                        >
                          <Plus className="size-3.5" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Cliente</Label>
                <Select value={clienteId} onValueChange={setClienteId}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sem">Sem cliente</SelectItem>
                    {clientes.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Pagamento</Label>
                <Select
                  value={pagamento}
                  onValueChange={(v) => setPagamento(v as Venda["pagamento"])}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pix">PIX</SelectItem>
                    <SelectItem value="dinheiro">Dinheiro</SelectItem>
                    <SelectItem value="cartao">Cartão</SelectItem>
                    <SelectItem value="transferencia">Transferência</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Situação</Label>
                <Select value={status} onValueChange={(v) => setStatus(v as Venda["status"])}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pago">Pago</SelectItem>
                    <SelectItem value="pendente">Pendente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="obs">Observações</Label>
                <Textarea
                  id="obs"
                  rows={2}
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                  placeholder="Entrega, recheio especial, horário..."
                />
              </div>
            </div>

            <div className="glass-inset rounded-2xl p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Custo estimado</span>
                <span className="tabular-nums">{brl(custo)}</span>
              </div>
              <div className="mt-1 flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Lucro estimado</span>
                <span className="font-medium text-success tabular-nums">{brl(total - custo)}</span>
              </div>
              <div className="mt-3 flex items-center justify-between">
                <span className="font-display text-lg">Total</span>
                <span className="font-display text-2xl font-semibold tabular-nums">
                  {brl(total)}
                </span>
              </div>
            </div>

            <Button
              className="w-full rounded-2xl"
              onClick={salvar}
              disabled={registrar.isPending || carrinho.length === 0}
            >
              <ShoppingCart className="size-4" /> Registrar venda
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </Estrutura>
  );
}
