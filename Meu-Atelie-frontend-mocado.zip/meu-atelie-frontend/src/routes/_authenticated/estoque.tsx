import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PackagePlus, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Estrutura } from "@/components/app/estrutura";
import { CartaoIndicador, Etiqueta, Painel, TituloSecao, Vazio } from "@/components/app/painel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { brl, num } from "@/lib/format";
import {
  statusInsumo,
  useApagarInsumo,
  useEntradaEstoque,
  useInsumos,
  useSalvarInsumo,
  type Insumo,
} from "@/lib/dados";

export const Route = createFileRoute("/_authenticated/estoque")({
  head: () => ({
    meta: [
      { title: "Estoque — Meu Ateliê" },
      {
        name: "description",
        content: "Controle de ingredientes e materiais com estoque mínimo e alertas de reposição.",
      },
      { property: "og:title", content: "Estoque — Meu Ateliê" },
      {
        property: "og:description",
        content: "Controle de ingredientes e materiais com estoque mínimo e alertas de reposição.",
      },
    ],
  }),
  component: PaginaEstoque,
});

const vazio = {
  nome: "",
  tipo: "ingrediente",
  unidade: "kg",
  quantidade: 0,
  minimo: 0,
  custo_unitario: 0,
} as Partial<Insumo>;

function PaginaEstoque() {
  const { data: insumos = [] } = useInsumos();
  const salvar = useSalvarInsumo();
  const apagar = useApagarInsumo();
  const entrada = useEntradaEstoque();

  const [filtro, setFiltro] = useState<"todos" | "ingrediente" | "material">("todos");
  const [aberto, setAberto] = useState(false);
  const [form, setForm] = useState<Partial<Insumo>>(vazio);
  const [compra, setCompra] = useState<{ insumo: Insumo; quantidade: string } | null>(null);

  const lista = useMemo(
    () => insumos.filter((i) => filtro === "todos" || i.tipo === filtro),
    [insumos, filtro],
  );

  const valorEstoque = insumos.reduce(
    (s, i) => s + Number(i.quantidade) * Number(i.custo_unitario),
    0,
  );
  const repor = insumos.filter((i) => statusInsumo(i) !== "ok");

  const confirmar = async () => {
    if (!form.nome?.trim()) {
      toast.error("Dê um nome ao item.");
      return;
    }
    try {
      await salvar.mutateAsync({
        ...form,
        quantidade: Number(form.quantidade) || 0,
        minimo: Number(form.minimo) || 0,
        custo_unitario: Number(form.custo_unitario) || 0,
      });
      toast.success("Item salvo.");
      setAberto(false);
    } catch (erro) {
      toast.error(erro instanceof Error ? erro.message : "Não foi possível salvar.");
    }
  };

  const registrarCompra = async () => {
    if (!compra) return;
    const qtd = Number(compra.quantidade.replace(",", "."));
    if (!qtd) {
      toast.error("Informe a quantidade comprada.");
      return;
    }
    await entrada.mutateAsync({ insumo: compra.insumo, quantidade: qtd, motivo: "Compra" });
    toast.success(`${compra.insumo.nome} reabastecido.`);
    setCompra(null);
  };

  return (
    <Estrutura
      titulo="Estoque"
      subtitulo="Ingredientes e materiais"
      acao={
        <Button
          className="rounded-2xl"
          onClick={() => {
            setForm(vazio);
            setAberto(true);
          }}
        >
          <Plus className="size-4" /> Novo item
        </Button>
      }
    >
      <section className="grid gap-4 sm:grid-cols-3">
        <CartaoIndicador
          rotulo="Itens cadastrados"
          valor={String(insumos.length)}
          detalhe={`${insumos.filter((i) => i.tipo === "ingrediente").length} ingredientes · ${insumos.filter((i) => i.tipo === "material").length} materiais`}
        />
        <CartaoIndicador
          rotulo="Valor em estoque"
          valor={brl(valorEstoque)}
          detalhe="Com base no custo por unidade"
          etiqueta="investido"
          tom="blossom"
        />
        <CartaoIndicador
          rotulo="Precisa repor"
          valor={String(repor.length)}
          detalhe={repor.map((i) => i.nome).slice(0, 3).join(", ") || "Tudo abastecido"}
          etiqueta={repor.length ? "atenção" : "ok"}
          tom={repor.length ? "danger" : "success"}
        />
      </section>

      <Painel className="p-6">
        <TituloSecao
          titulo="Itens em estoque"
          descricao="Abaixo do mínimo aparece marcado em vermelho"
          acao={
            <Tabs value={filtro} onValueChange={(v) => setFiltro(v as typeof filtro)}>
              <TabsList className="rounded-full">
                <TabsTrigger value="todos" className="rounded-full text-xs">
                  Todos
                </TabsTrigger>
                <TabsTrigger value="ingrediente" className="rounded-full text-xs">
                  Ingredientes
                </TabsTrigger>
                <TabsTrigger value="material" className="rounded-full text-xs">
                  Materiais
                </TabsTrigger>
              </TabsList>
            </Tabs>
          }
        />
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[680px] text-sm">
            <thead>
              <tr className="border-b border-border text-[11px] tracking-wider text-muted-foreground uppercase">
                <th className="py-2 pr-4 text-left font-medium">Item</th>
                <th className="py-2 pr-4 text-left font-medium">Tipo</th>
                <th className="py-2 pr-4 text-right font-medium">Quantidade</th>
                <th className="py-2 pr-4 text-right font-medium">Mínimo</th>
                <th className="py-2 pr-4 text-right font-medium">Custo/unid.</th>
                <th className="py-2 pr-4 text-right font-medium">Situação</th>
                <th className="py-2 text-right font-medium">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {lista.map((insumo) => {
                const situacao = statusInsumo(insumo);
                return (
                  <tr key={insumo.id} className="transition-colors hover:bg-card/50">
                    <td className="py-2.5 pr-4 font-medium">{insumo.nome}</td>
                    <td className="py-2.5 pr-4 text-muted-foreground">{insumo.tipo}</td>
                    <td className="py-2.5 pr-4 text-right tabular-nums">
                      {num(Number(insumo.quantidade))} {insumo.unidade}
                    </td>
                    <td className="py-2.5 pr-4 text-right text-muted-foreground tabular-nums">
                      {num(Number(insumo.minimo))}
                    </td>
                    <td className="py-2.5 pr-4 text-right tabular-nums">
                      {brl(Number(insumo.custo_unitario))}
                    </td>
                    <td className="py-2.5 pr-4 text-right">
                      <Etiqueta
                        tom={
                          situacao === "ok" ? "success" : situacao === "baixo" ? "warning" : "danger"
                        }
                      >
                        {situacao === "ok" ? "ok" : situacao === "baixo" ? "baixo" : "acabou"}
                      </Etiqueta>
                    </td>
                    <td className="py-2.5 text-right whitespace-nowrap">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 rounded-full text-brand"
                        aria-label="Registrar compra"
                        onClick={() => setCompra({ insumo, quantidade: "" })}
                      >
                        <PackagePlus className="size-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 rounded-full"
                        aria-label="Editar"
                        onClick={() => {
                          setForm({ ...insumo });
                          setAberto(true);
                        }}
                      >
                        <Pencil className="size-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 rounded-full text-muted-foreground"
                        aria-label="Apagar"
                        onClick={() => apagar.mutate(insumo.id)}
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {lista.length === 0 ? <Vazio texto="Nenhum item por aqui." /> : null}
        </div>
      </Painel>

      <Dialog open={aberto} onOpenChange={setAberto}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-display text-xl">
              {form.id ? "Editar item" : "Novo item"}
            </DialogTitle>
            <DialogDescription>
              Ingredientes e materiais usados na produção, com o mínimo que você quer ter em casa.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="nome-insumo">Nome</Label>
              <Input
                id="nome-insumo"
                value={form.nome ?? ""}
                onChange={(e) => setForm({ ...form, nome: e.target.value })}
                placeholder="Chocolate 60%"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Tipo</Label>
              <Select
                value={form.tipo ?? "ingrediente"}
                onValueChange={(v) => setForm({ ...form, tipo: v as Insumo["tipo"] })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ingrediente">Ingrediente</SelectItem>
                  <SelectItem value="material">Material</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Unidade</Label>
              <Select
                value={form.unidade ?? "kg"}
                onValueChange={(v) => setForm({ ...form, unidade: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="kg">kg</SelectItem>
                  <SelectItem value="g">g</SelectItem>
                  <SelectItem value="l">l</SelectItem>
                  <SelectItem value="ml">ml</SelectItem>
                  <SelectItem value="un">un</SelectItem>
                  <SelectItem value="m">m</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="qtd">Quantidade atual</Label>
              <Input
                id="qtd"
                type="number"
                step="0.01"
                value={String(form.quantidade ?? 0)}
                onChange={(e) => setForm({ ...form, quantidade: Number(e.target.value) })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="min">Estoque mínimo</Label>
              <Input
                id="min"
                type="number"
                step="0.01"
                value={String(form.minimo ?? 0)}
                onChange={(e) => setForm({ ...form, minimo: Number(e.target.value) })}
              />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="custo">Custo por unidade (R$)</Label>
              <Input
                id="custo"
                type="number"
                step="0.01"
                value={String(form.custo_unitario ?? 0)}
                onChange={(e) => setForm({ ...form, custo_unitario: Number(e.target.value) })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="rounded-2xl" onClick={() => setAberto(false)}>
              Cancelar
            </Button>
            <Button className="rounded-2xl" onClick={confirmar} disabled={salvar.isPending}>
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={compra !== null} onOpenChange={(v) => !v && setCompra(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">Registrar compra</DialogTitle>
            <DialogDescription>
              Quanto de {compra?.insumo.nome} entrou no estoque?
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="entrada">Quantidade em {compra?.insumo.unidade}</Label>
            <Input
              id="entrada"
              inputMode="decimal"
              value={compra?.quantidade ?? ""}
              onChange={(e) =>
                setCompra((atual) => (atual ? { ...atual, quantidade: e.target.value } : atual))
              }
              placeholder="2"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" className="rounded-2xl" onClick={() => setCompra(null)}>
              Cancelar
            </Button>
            <Button className="rounded-2xl" onClick={registrarCompra} disabled={entrada.isPending}>
              Adicionar ao estoque
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Estrutura>
  );
}
