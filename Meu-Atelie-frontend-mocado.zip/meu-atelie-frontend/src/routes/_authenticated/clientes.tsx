import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Estrutura } from "@/components/app/estrutura";
import { Etiqueta, Painel, TituloSecao, Vazio } from "@/components/app/painel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { brl } from "@/lib/format";
import {
  useApagarCliente,
  useClientes,
  useSalvarCliente,
  useVendas,
  type Cliente,
} from "@/lib/dados";

export const Route = createFileRoute("/_authenticated/clientes")({
  head: () => ({
    meta: [
      { title: "Clientes — Meu Ateliê" },
      {
        name: "description",
        content: "Lista de clientes da confeitaria com contato, preferências e total comprado.",
      },
      { property: "og:title", content: "Clientes — Meu Ateliê" },
      {
        property: "og:description",
        content: "Lista de clientes da confeitaria com contato, preferências e total comprado.",
      },
    ],
  }),
  component: PaginaClientes,
});

function PaginaClientes() {
  const { data: clientes = [] } = useClientes();
  const { data: vendas = [] } = useVendas();
  const salvar = useSalvarCliente();
  const apagar = useApagarCliente();

  const [aberto, setAberto] = useState(false);
  const [form, setForm] = useState<Partial<Cliente>>({});

  const confirmar = async () => {
    if (!form.nome?.trim()) {
      toast.error("Informe o nome do cliente.");
      return;
    }
    await salvar.mutateAsync(form);
    toast.success("Cliente salvo.");
    setAberto(false);
  };

  return (
    <Estrutura
      titulo="Clientes"
      subtitulo="Quem compra com você"
      acao={
        <Button
          className="rounded-2xl"
          onClick={() => {
            setForm({});
            setAberto(true);
          }}
        >
          <Plus className="size-4" /> Novo cliente
        </Button>
      }
    >
      <Painel className="p-6">
        <TituloSecao
          titulo="Lista de clientes"
          descricao={`${clientes.length} ${clientes.length === 1 ? "cliente" : "clientes"}`}
        />
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {clientes.length === 0 ? (
            <div className="sm:col-span-2">
              <Vazio texto="Nenhum cliente cadastrado ainda." />
            </div>
          ) : (
            clientes.map((cliente) => {
              const compras = vendas.filter(
                (v) => v.cliente_id === cliente.id && v.status !== "cancelado",
              );
              const total = compras.reduce((s, v) => s + Number(v.total), 0);
              return (
                <div key={cliente.id} className="glass-inset rounded-2xl p-4">
                  <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
                    <div className="min-w-0">
                      <p className="truncate font-medium">{cliente.nome}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {cliente.telefone ?? "Sem telefone"}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 rounded-full"
                        aria-label="Editar"
                        onClick={() => {
                          setForm({ ...cliente });
                          setAberto(true);
                        }}
                      >
                        <Pencil className="size-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 rounded-full text-muted-foreground"
                        aria-label="Apagar"
                        onClick={() => apagar.mutate(cliente.id)}
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  </div>
                  {cliente.observacoes ? (
                    <p className="mt-2 text-xs text-muted-foreground">{cliente.observacoes}</p>
                  ) : null}
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    <Etiqueta tom="brand">{compras.length} compras</Etiqueta>
                    <Etiqueta tom="success">{brl(total)} no total</Etiqueta>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </Painel>

      <Dialog open={aberto} onOpenChange={setAberto}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-display text-xl">
              {form.id ? "Editar cliente" : "Novo cliente"}
            </DialogTitle>
            <DialogDescription>Nome, contato e preferências de recheio ou entrega.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="nome-cliente">Nome</Label>
              <Input
                id="nome-cliente"
                value={form.nome ?? ""}
                onChange={(e) => setForm({ ...form, nome: e.target.value })}
                placeholder="Marina Lopes"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="telefone">Telefone</Label>
              <Input
                id="telefone"
                value={form.telefone ?? ""}
                onChange={(e) => setForm({ ...form, telefone: e.target.value })}
                placeholder="(11) 90000-0000"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="obs-cliente">Observações</Label>
              <Textarea
                id="obs-cliente"
                rows={3}
                value={form.observacoes ?? ""}
                onChange={(e) => setForm({ ...form, observacoes: e.target.value })}
                placeholder="Prefere bolo menos doce, retira em casa..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="rounded-2xl" onClick={() => setAberto(false)}>
              Cancelar
            </Button>
            <Button className="rounded-2xl" onClick={confirmar} disabled={salvar.isPending}>
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Estrutura>
  );
}
