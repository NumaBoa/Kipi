import { Link } from "@tanstack/react-router";
import {
  BarChart3,
  Boxes,
  CakeSlice,
  LayoutDashboard,
  Moon,
  NotebookPen,
  ShoppingBag,
  Sun,
  Users,
} from "lucide-react";
import type { ReactNode } from "react";
import { useTema } from "@/lib/theme";
import { hoje } from "@/lib/format";
import { cn } from "@/lib/utils";

const itens = [
  { para: "/", rotulo: "Painel", Icone: LayoutDashboard },
  { para: "/vendas", rotulo: "Vendas", Icone: ShoppingBag },
  { para: "/produtos", rotulo: "Produtos", Icone: CakeSlice },
  { para: "/estoque", rotulo: "Estoque", Icone: Boxes },
  { para: "/receitas", rotulo: "Receitas", Icone: NotebookPen },
  { para: "/clientes", rotulo: "Clientes", Icone: Users },
  { para: "/relatorios", rotulo: "Relatórios", Icone: BarChart3 },
] as const;

function Fundo() {
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden">
      <div className="blob-a absolute -top-24 -left-24 h-96 w-96 rounded-full bg-brand/25 blur-3xl" />
      <div className="blob-b absolute top-1/3 -right-16 h-[28rem] w-[28rem] rounded-full bg-blossom/20 blur-3xl" />
      <div className="blob-a absolute -bottom-20 left-1/3 h-80 w-80 rounded-full bg-chart-3/25 blur-3xl" />
    </div>
  );
}

function Navegacao({ compacto = false }: { compacto?: boolean }) {
  return (
    <nav className={cn("space-y-1 text-sm font-medium", compacto && "flex gap-1 space-y-0")}>
      {itens.map(({ para, rotulo, Icone }) => (
        <Link
          key={para}
          to={para}
          activeOptions={{ exact: para === "/" }}
          activeProps={{ className: "bg-brand/12 text-brand" }}
          inactiveProps={{ className: "text-muted-foreground hover:bg-card/60" }}
          className={cn(
            "flex items-center gap-3 rounded-2xl px-3 py-2.5 transition-colors",
            compacto && "flex-col gap-1 px-3 py-2 text-[11px]",
          )}
        >
          <span className="grid size-7 shrink-0 place-items-center rounded-xl bg-foreground/5">
            <Icone className="size-4" />
          </span>
          {rotulo}
        </Link>
      ))}
    </nav>
  );
}

export function Estrutura({
  titulo,
  subtitulo,
  acao,
  children,
}: {
  titulo: string;
  subtitulo?: string;
  acao?: ReactNode;
  children: ReactNode;
}) {
  const { tema, alternar } = useTema();
  return (
    <div className="relative min-h-screen w-full overflow-x-hidden bg-background text-foreground">
      <Fundo />
      <div className="relative z-10 mx-auto flex max-w-[1440px] gap-6 px-4 py-4 sm:px-6 sm:py-6">
        <aside className="hidden w-60 shrink-0 lg:block">
          <div className="glass-panel sticky top-6 rounded-3xl p-4">
            <div className="flex items-center gap-2.5 px-2 pb-5">
              <div className="gradient-brand grid size-10 shrink-0 place-items-center rounded-2xl font-display text-lg text-primary-foreground">
                A
              </div>
              <div className="min-w-0">
                <p className="truncate font-display text-lg leading-none font-semibold">
                  Meu Ateliê
                </p>
                <p className="text-[11px] text-muted-foreground">Bolos, cookies e artesanato</p>
              </div>
            </div>
            <Navegacao />
            <div className="mt-5 rounded-2xl bg-brand/10 p-3">
              <p className="text-xs font-semibold">Tema</p>
              <p className="mt-1 text-[11px] leading-snug text-muted-foreground">
                Claro para o dia, escuro para as noites de produção.
              </p>
              <button
                type="button"
                onClick={alternar}
                className="mt-2.5 flex w-full items-center justify-between rounded-xl bg-card/70 px-3 py-2 text-[11px] font-medium transition-colors hover:bg-card"
              >
                {tema === "dark" ? "Modo escuro" : "Modo claro"}
                {tema === "dark" ? <Moon className="size-3.5" /> : <Sun className="size-3.5" />}
              </button>
            </div>
          </div>
        </aside>

        <main className="min-w-0 flex-1 space-y-5">
          <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
            <div className="min-w-0">
              <p className="truncate text-[11px] font-medium tracking-[0.18em] text-muted-foreground uppercase">
                {subtitulo ?? hoje()}
              </p>
              <h1 className="truncate text-2xl md:text-3xl">{titulo}</h1>
            </div>
            <div className="flex items-center gap-2">
              {acao}
              <button
                type="button"
                onClick={alternar}
                aria-label="Alternar tema"
                className="glass-panel grid size-11 shrink-0 place-items-center rounded-2xl lg:hidden"
              >
                {tema === "dark" ? <Moon className="size-4" /> : <Sun className="size-4" />}
              </button>
            </div>
          </header>

          {children}

          <div className="glass-panel sticky bottom-0 z-20 -mx-1 overflow-x-auto rounded-3xl p-2 lg:hidden">
            <Navegacao compacto />
          </div>
        </main>
      </div>
    </div>
  );
}
