import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

export type Insumo = { id: string; nome: string; tipo: "ingrediente" | "material"; unidade: string; quantidade: number; minimo: number; custo_unitario: number };
export type Produto = { id: string; nome: string; categoria: "bolo" | "cookie" | "artesanato" | "outro"; preco: number; estoque: number; ativo: boolean };
export type Cliente = { id: string; nome: string; telefone: string | null; observacoes: string | null };
export type ReceitaItem = { id: string; produto_id: string; insumo_id: string; quantidade: number };
export type VendaItem = { id: string; venda_id: string; produto_id: string | null; nome_produto: string; quantidade: number; preco_unitario: number };
export type Venda = { id: string; cliente_id: string | null; data: string; pagamento: "pix" | "dinheiro" | "cartao" | "transferencia"; status: "pago" | "pendente" | "cancelado"; total: number; custo_total: number; observacoes: string | null; venda_itens: VendaItem[]; clientes: { nome: string } | null };
export type ItemCarrinho = { produto: Produto; quantidade: number };

type Dados = { insumos: Insumo[]; produtos: Produto[]; clientes: Cliente[]; receitas: ReceitaItem[]; vendas: Venda[] };
const CHAVE = "meu-atelie-dados-mocados-v1";
const haDias = (dias: number, hora = 14) => { const d = new Date(); d.setDate(d.getDate() - dias); d.setHours(hora, 0, 0, 0); return d.toISOString(); };

const iniciais: Dados = {
  insumos: [
    { id: "i1", nome: "Farinha de trigo", tipo: "ingrediente", unidade: "kg", quantidade: 8.5, minimo: 3, custo_unitario: 6.9 },
    { id: "i2", nome: "Chocolate 60%", tipo: "ingrediente", unidade: "kg", quantidade: 1.2, minimo: 2, custo_unitario: 48 },
    { id: "i3", nome: "Ovos", tipo: "ingrediente", unidade: "un", quantidade: 42, minimo: 18, custo_unitario: 0.92 },
    { id: "i4", nome: "Açúcar mascavo", tipo: "ingrediente", unidade: "kg", quantidade: 0, minimo: 2, custo_unitario: 10.5 },
    { id: "i5", nome: "Manteiga", tipo: "ingrediente", unidade: "kg", quantidade: 3.4, minimo: 1.5, custo_unitario: 39.9 },
    { id: "i6", nome: "Leite condensado", tipo: "ingrediente", unidade: "un", quantidade: 9, minimo: 6, custo_unitario: 7.8 },
    { id: "i7", nome: "Caixa para bolo", tipo: "material", unidade: "un", quantidade: 7, minimo: 10, custo_unitario: 4.2 },
    { id: "i8", nome: "Saquinho para cookie", tipo: "material", unidade: "un", quantidade: 64, minimo: 30, custo_unitario: 0.55 },
    { id: "i9", nome: "Fita de cetim", tipo: "material", unidade: "m", quantidade: 18, minimo: 10, custo_unitario: 1.4 }
  ],
  produtos: [
    { id: "p1", nome: "Bolo de cenoura", categoria: "bolo", preco: 65, estoque: 3, ativo: true },
    { id: "p2", nome: "Bolo Red Velvet", categoria: "bolo", preco: 120, estoque: 1, ativo: true },
    { id: "p3", nome: "Cookie clássico", categoria: "cookie", preco: 9, estoque: 24, ativo: true },
    { id: "p4", nome: "Cookie de chocolate", categoria: "cookie", preco: 11, estoque: 18, ativo: true },
    { id: "p5", nome: "Caixa com 6 cookies", categoria: "cookie", preco: 52, estoque: 8, ativo: true },
    { id: "p6", nome: "Kit presente artesanal", categoria: "artesanato", preco: 78, estoque: 5, ativo: true }
  ],
  clientes: [
    { id: "c1", nome: "Marina Lopes", telefone: "(11) 98765-4321", observacoes: "Prefere recheios menos doces." },
    { id: "c2", nome: "Ana Paula", telefone: "(11) 91234-8877", observacoes: "Retira aos sábados." },
    { id: "c3", nome: "Carla Mendes", telefone: "(11) 99876-1122", observacoes: null },
    { id: "c4", nome: "Rafael Lima", telefone: "(11) 93456-7788", observacoes: "Encomendas para o escritório." },
    { id: "c5", nome: "Juliana Reis", telefone: "(11) 97654-2233", observacoes: "Gosta de embalagens para presente." }
  ],
  receitas: [
    { id: "r1", produto_id: "p1", insumo_id: "i1", quantidade: 0.35 }, { id: "r2", produto_id: "p1", insumo_id: "i3", quantidade: 4 },
    { id: "r3", produto_id: "p1", insumo_id: "i6", quantidade: 1 }, { id: "r4", produto_id: "p1", insumo_id: "i7", quantidade: 1 },
    { id: "r5", produto_id: "p2", insumo_id: "i1", quantidade: 0.5 }, { id: "r6", produto_id: "p2", insumo_id: "i3", quantidade: 5 },
    { id: "r7", produto_id: "p2", insumo_id: "i5", quantidade: 0.25 }, { id: "r8", produto_id: "p2", insumo_id: "i7", quantidade: 1 },
    { id: "r9", produto_id: "p3", insumo_id: "i1", quantidade: 0.06 }, { id: "r10", produto_id: "p3", insumo_id: "i4", quantidade: 0.025 },
    { id: "r11", produto_id: "p3", insumo_id: "i5", quantidade: 0.03 }, { id: "r12", produto_id: "p3", insumo_id: "i8", quantidade: 1 },
    { id: "r13", produto_id: "p4", insumo_id: "i2", quantidade: 0.04 }, { id: "r14", produto_id: "p4", insumo_id: "i1", quantidade: 0.055 },
    { id: "r15", produto_id: "p4", insumo_id: "i5", quantidade: 0.03 }, { id: "r16", produto_id: "p4", insumo_id: "i8", quantidade: 1 }
  ],
  vendas: []
};

const vendasBase = [
  [0,"c1","pix","p1",1],[0,"c3","cartao","p3",4],[1,"c2","pix","p5",1],[2,"c4","transferencia","p4",8],
  [3,"c5","dinheiro","p6",1],[4,"c1","pix","p2",1],[5,"c3","cartao","p3",6],[6,"c2","pix","p1",1],
  [8,"c4","pix","p5",2],[11,"c5","cartao","p4",5],[14,"c1","transferencia","p2",1],[17,"c3","pix","p3",10],
  [21,"c2","dinheiro","p6",1],[25,"c4","cartao","p1",2],[31,"c5","pix","p5",1],[38,"c1","pix","p4",7],
  [45,"c2","cartao","p2",1],[53,"c3","dinheiro","p3",8],[67,"c4","pix","p1",1],[82,"c5","transferencia","p6",2]
] as const;
iniciais.vendas = vendasBase.map(([dias, clienteId, pagamento, produtoId, quantidade], index) => {
  const produto = iniciais.produtos.find((p) => p.id === produtoId);
  if (!produto) throw new Error("Produto fictício não encontrado");
  const cliente = iniciais.clientes.find((c) => c.id === clienteId);
  const total = produto.preco * quantidade;
  const custo = produtoId === "p2" ? 33 : produtoId === "p1" ? 17 : produtoId === "p6" ? 31 : 3.8;
  const id = `v${index + 1}`;
  return { id, cliente_id: clienteId, data: haDias(dias, 10 + index % 8), pagamento, status: index === 2 || index === 9 ? "pendente" : "pago", total, custo_total: custo * quantidade, observacoes: index === 0 ? "Retirada às 17h" : null, clientes: cliente ? { nome: cliente.nome } : null, venda_itens: [{ id: `vi${index + 1}`, venda_id: id, produto_id: produtoId, nome_produto: produto.nome, quantidade, preco_unitario: produto.preco }] } as Venda;
});

const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v)) as T;
function ler(): Dados { if (typeof window === "undefined") return clone(iniciais); const salvo = localStorage.getItem(CHAVE); if (!salvo) { localStorage.setItem(CHAVE, JSON.stringify(iniciais)); return clone(iniciais); } try { return JSON.parse(salvo) as Dados; } catch { return clone(iniciais); } }
function gravar(d: Dados) { if (typeof window !== "undefined") localStorage.setItem(CHAVE, JSON.stringify(d)); }
const id = () => typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
export const chaves = { insumos:["insumos"] as const, produtos:["produtos"] as const, clientes:["clientes"] as const, receitas:["receitas"] as const, vendas:["vendas"] as const };
const consulta = <K extends keyof Dados>(chave: K) => useQuery({ queryKey: chaves[chave], queryFn: () => ler()[chave] });
export const useInsumos = () => consulta("insumos"); export const useProdutos = () => consulta("produtos"); export const useClientes = () => consulta("clientes"); export const useReceitas = () => consulta("receitas"); export const useVendas = () => consulta("vendas");
export function custoProduto(produtoId: string, receitas: ReceitaItem[], insumos: Insumo[]) { return receitas.filter(r => r.produto_id === produtoId).reduce((t,r) => t + (insumos.find(i => i.id === r.insumo_id)?.custo_unitario ?? 0) * r.quantidade, 0); }
export function statusInsumo(i: Insumo) { return i.quantidade <= 0 ? "acabou" as const : i.quantidade <= i.minimo ? "baixo" as const : "ok" as const; }
function useAlterar<T>(chavesInvalidar: readonly (readonly string[])[], fn: (dados: Dados, valor: T) => void) { const qc=useQueryClient(); return useMutation({ mutationFn: async (valor:T) => { const dados=ler(); fn(dados,valor); gravar(dados); }, onSuccess:()=>chavesInvalidar.forEach(queryKey=>qc.invalidateQueries({queryKey})) }); }
export const useSalvarInsumo=()=>useAlterar<Partial<Insumo>>([chaves.insumos],(d,v)=>{ const pos=d.insumos.findIndex(x=>x.id===v.id); const novo={id:v.id??id(),nome:v.nome??"",tipo:v.tipo??"ingrediente",unidade:v.unidade??"kg",quantidade:Number(v.quantidade??0),minimo:Number(v.minimo??0),custo_unitario:Number(v.custo_unitario??0)}; pos>=0?d.insumos.splice(pos,1,novo):d.insumos.push(novo); });
export const useApagarInsumo=()=>useAlterar<string>([chaves.insumos],(d,v)=>{d.insumos=d.insumos.filter(x=>x.id!==v)});
export const useEntradaEstoque=()=>useAlterar<{insumo:Insumo;quantidade:number;motivo:string}>([chaves.insumos],(d,v)=>{const x=d.insumos.find(i=>i.id===v.insumo.id);if(x)x.quantidade+=v.quantidade});
export const useSalvarProduto=()=>useAlterar<Partial<Produto>>([chaves.produtos],(d,v)=>{const pos=d.produtos.findIndex(x=>x.id===v.id);const novo={id:v.id??id(),nome:v.nome??"",categoria:v.categoria??"bolo",preco:Number(v.preco??0),estoque:Number(v.estoque??0),ativo:v.ativo??true};pos>=0?d.produtos.splice(pos,1,novo):d.produtos.push(novo)});
export const useApagarProduto=()=>useAlterar<string>([chaves.produtos,chaves.receitas],(d,v)=>{d.produtos=d.produtos.filter(x=>x.id!==v);d.receitas=d.receitas.filter(x=>x.produto_id!==v)});
export const useSalvarCliente=()=>useAlterar<Partial<Cliente>>([chaves.clientes],(d,v)=>{const pos=d.clientes.findIndex(x=>x.id===v.id);const novo={id:v.id??id(),nome:v.nome??"",telefone:v.telefone??null,observacoes:v.observacoes??null};pos>=0?d.clientes.splice(pos,1,novo):d.clientes.push(novo)});
export const useApagarCliente=()=>useAlterar<string>([chaves.clientes],(d,v)=>{d.clientes=d.clientes.filter(x=>x.id!==v)});
export const useSalvarReceitaItem=()=>useAlterar<Omit<ReceitaItem,"id">>([chaves.receitas],(d,v)=>d.receitas.push({...v,id:id()}));
export const useApagarReceitaItem=()=>useAlterar<string>([chaves.receitas],(d,v)=>{d.receitas=d.receitas.filter(x=>x.id!==v)});
export const useAtualizarVenda=()=>useAlterar<{id:string;status:Venda["status"]}>([chaves.vendas],(d,v)=>{const x=d.vendas.find(i=>i.id===v.id);if(x)x.status=v.status});
export const useApagarVenda=()=>useAlterar<string>([chaves.vendas],(d,v)=>{d.vendas=d.vendas.filter(x=>x.id!==v)});
export const useRegistrarVenda=()=>useAlterar<{itens:ItemCarrinho[];clienteId:string|null;pagamento:Venda["pagamento"];status:Venda["status"];observacoes:string;receitas:ReceitaItem[];insumos:Insum[]}>([chaves.vendas,chaves.produtos,chaves.insumos],(d,v)=>{const vendaId=id();const cliente=d.clientes.find(c=>c.id===v.clienteId);const total=v.itens.reduce((s,i)=>s+i.produto.preco*i.quantidade,0);const custo=v.itens.reduce((s,i)=>s+custoProduto(i.produto.id,v.receitas,v.insumos)*i.quantidade,0);d.vendas.unshift({id:vendaId,cliente_id:v.clienteId,data:new Date().toISOString(),pagamento:v.pagamento,status:v.status,total,custo_total:custo,observacoes:v.observacoes||null,clientes:cliente?{nome:cliente.nome}:null,venda_itens:v.itens.map(i=>({id:id(),venda_id:vendaId,produto_id:i.produto.id,nome_produto:i.produto.nome,quantidade:i.quantidade,preco_unitario:i.produto.preco}))});for(const item of v.itens){const p=d.produtos.find(x=>x.id===item.produto.id);if(p)p.estoque=Math.max(0,p.estoque-item.quantidade);for(const r of d.receitas.filter(x=>x.produto_id===item.produto.id)){const ins=d.insumos.find(x=>x.id===r.insumo_id);if(ins)ins.quantidade=Math.max(0,ins.quantidade-r.quantidade*item.quantidade)}}});
